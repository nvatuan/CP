#include <bits/stdc++.h>
using namespace std;

int n;

int main() {
    cin >> n;
    cout << string(n, '0') << string(n, '1') << '\n';
    for (int i=0; i<n; i++) {
        cout << '0' << '1';
    }
    cout << '\n';
}